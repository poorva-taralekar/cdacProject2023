package com.app.entities;

public enum ROLE {
    ADMIN,GUEST,OWNER;
}
