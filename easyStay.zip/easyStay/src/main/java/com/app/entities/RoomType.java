package com.app.entities;

public enum RoomType {
	AC,Deluxe,NonAC;
}
